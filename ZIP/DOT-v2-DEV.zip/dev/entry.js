import DynamicOpenText from "./DynamicOpenText";

if (window && !window.customQuestionsLibrary) {
    window.customQuestionsLibrary = {};
}
window.customQuestionsLibrary.DynamicOpenText = DynamicOpenText;
